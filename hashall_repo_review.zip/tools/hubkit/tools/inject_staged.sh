#!/usr/bin/env bash
set -euo pipefail

# GPTrail Inject Staged Script 🧠🔗

REPO_ROOT=$(git rev-parse --show-toplevel)
cd "$REPO_ROOT"

FORCE=false
if [[ "${1:-}" == "--force" ]]; then
  FORCE=true
fi

# 🩹 Extract first slug from trail.yaml
SLUG=$(grep -E '^\s*-\s*slug:' .gpt/trail.yaml | head -n1 | awk '{print $3}')
if [[ -z "$SLUG" ]]; then
  echo "❌ No 'slug:' found in .gpt/trail.yaml"
  echo "💡 You might need to run: gptrail --new ..."
  exit 1
fi

SLUG_LINE="# gptrail: $SLUG"

STAGED=$(git diff --cached --name-only)

for FILE in $STAGED; do
  # 🛑 Skip deleted or binary files
  if [[ ! -f "$FILE" ]]; then
    continue
  fi

  # 🔍 Only inject into certain types
  case "$FILE" in
    *.py|*.sh|*.md|*.yaml|*.yml|*.toml|*.conf|*.txt) ;;
    *) continue ;;
  esac

  CONTENT=$(<"$FILE")

  # 🧹 Remove any previous gptrail block
  CLEANED=$(awk "
    BEGIN { inside=0 }
    \$0 ~ /$SLUG_START/ { inside=1; next }
    \$0 ~ /$SLUG_END/ { inside=0; next }
    inside == 0 { print }
  " <<< "$CONTENT")

  # 🏁 Preserve shebang
  SHEBANG=""
  REST="$CLEANED"
  if [[ "$CLEANED" =~ ^(\#\!.*)$'\n'(.*) ]]; then
    SHEBANG="${BASH_REMATCH[1]}"
    REST="${CLEANED#*$'\n'}"
  fi

  # ✨ Construct injected block
  BLOCK="$SLUG_START"$'\n'"$SLUG_LINE"$'\n'"$SLUG_END"

  FINAL_CONTENT=""
  if [[ -n "$SHEBANG" ]]; then
    FINAL_CONTENT="$SHEBANG"$'\n'"$BLOCK"$'\n'"$REST"
  else
    FINAL_CONTENT="$BLOCK"$'\n'"$REST"
  fi

  # 📦 Write back
  TMP_FILE="${FILE}.gptrail.tmp"
  echo "$FINAL_CONTENT" > "$TMP_FILE"
  mv "$TMP_FILE" "$FILE"

  echo "✅ Injected slug into: $FILE"

  if $FORCE; then
    git add "$FILE"
  fi
# === gptrail slugs start ===
# gptrail: jake-gptrail-001-04Jun25-kickoff-8af4be
# === gptrail slugs end ===
set -euo pipefail

# GPTrail Inject Staged Script 🧠🔗

REPO_ROOT=$(git rev-parse --show-toplevel)
cd "$REPO_ROOT"

FORCE=false
if [[ "${1:-}" == "--force" ]]; then
  FORCE=true
fi

# 🩹 Extract first slug from trail.yaml
SLUG=$(grep -E '^\s*-\s*slug:' .gpt/trail.yaml | head -n1 | awk '{print $3}')
if [[ -z "$SLUG" ]]; then
  echo "❌ No 'slug:' found in .gpt/trail.yaml"
  echo "💡 You might need to run: gptrail --new ..."
  exit 1
fi

SLUG_LINE="# gptrail: $SLUG"

STAGED=$(git diff --cached --name-only)

for FILE in $STAGED; do
  # 🛑 Skip deleted or binary files
  if [[ ! -f "$FILE" ]]; then
    continue
  fi

  # 🔍 Only inject into certain types
  case "$FILE" in
    *.py|*.sh|*.md|*.yaml|*.yml|*.toml|*.conf|*.txt) ;;
    *) continue ;;
  esac

  CONTENT=$(<"$FILE")

  # 🧹 Remove any previous gptrail block
  CLEANED=$(awk "
    BEGIN { inside=0 }
    \$0 ~ /$SLUG_START/ { inside=1; next }
    \$0 ~ /$SLUG_END/ { inside=0; next }
    inside == 0 { print }
  " <<< "$CONTENT")

  # 🏁 Preserve shebang
  SHEBANG=""
  REST="$CLEANED"
  if [[ "$CLEANED" =~ ^(\#\!.*)$'\n'(.*) ]]; then
    SHEBANG="${BASH_REMATCH[1]}"
    REST="${CLEANED#*$'\n'}"
  fi

  # ✨ Construct injected block
  BLOCK="$SLUG_START"$'\n'"$SLUG_LINE"$'\n'"$SLUG_END"

  FINAL_CONTENT=""
  if [[ -n "$SHEBANG" ]]; then
    FINAL_CONTENT="$SHEBANG"$'\n'"$BLOCK"$'\n'"$REST"
  else
    FINAL_CONTENT="$BLOCK"$'\n'"$REST"
  fi

  # 📦 Write back
  TMP_FILE="${FILE}.gptrail.tmp"
  echo "$FINAL_CONTENT" > "$TMP_FILE"
  mv "$TMP_FILE" "$FILE"

  echo "✅ Injected slug into: $FILE"

  if $FORCE; then
    git add "$FILE"
  fi
done
