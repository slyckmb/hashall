#!/bin/bash
# tools/pre-commit-gptrail.sh

set -e

echo "🧪 Running GPTrail staged injection..."

# Capture staged files before injection
PRE_STAGED=$(git diff --cached --name-only)

# Run the actual injector
tools/inject_staged.sh --force

# Capture changed files after injection
CHANGED=$(git diff --name-only)

# Re-stage only those that were originally staged
for file in $CHANGED; do
  if echo "$PRE_STAGED" | grep -qx "$file"; then
    echo "🔄 Re-staging modified file: $file"
    git add "$file"
  fi
done

# === gptrail slugs start ===
# gptrail: jake-gptrail-001-04Jun25-kickoff-8af4be
# === gptrail slugs end ===
# tools/pre-commit-gptrail.sh

set -e

echo "🧪 Running GPTrail staged injection..."

# Capture staged files before injection
PRE_STAGED=$(git diff --cached --name-only)

# Run the actual injector
tools/inject_staged.sh --force

# Capture changed files after injection
CHANGED=$(git diff --name-only)

# Re-stage only those that were originally staged
for file in $CHANGED; do
  if echo "$PRE_STAGED" | grep -qx "$file"; then
    echo "🔄 Re-staging modified file: $file"
    git add "$file"
  fi
done

echo "✅ GPTrail pre-commit hook completed."
