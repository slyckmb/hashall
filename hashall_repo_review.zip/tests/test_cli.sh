#!/bin/bash
set -e

echo "🔁 Uninstalling previous hashall..."
pip uninstall -y hashall || true

echo "📦 Reinstalling in editable mode..."
pip install -e .

echo "✅ Verifying CLI entrypoint..."
hashall --version
hashall --help

echo "📂 Testing scan..."
hashall scan ~/Downloads --db /tmp/test_hashall.sqlite3

echo "📤 Testing export..."
hashall export /tmp/test_hashall.sqlite3 --out /tmp/test_export.json

echo "🔍 Testing verify..."
hashall verify --src /tmp/test_hashall.sqlite3 --dst /tmp/test_hashall.sqlite3

echo "🌲 Testing verify-trees..."
hashall verify-trees ~/Downloads --db /tmp/test_hashall.sqlite3

echo "✅ All commands ran successfully!"