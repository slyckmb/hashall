-- migrations/0001_add_treehash_fields.sql

ALTER TABLE scan_session ADD COLUMN treehash TEXT;
ALTER TABLE files ADD COLUMN inode INTEGER;
ALTER TABLE files ADD COLUMN device_id INTEGER;
ALTER TABLE files ADD COLUMN is_hardlink INTEGER DEFAULT 0;

CREATE TABLE IF NOT EXISTS tree_hashes (
    id INTEGER PRIMARY KEY,
    scan_session_id INTEGER NOT NULL REFERENCES scan_session(id) ON DELETE CASCADE,
    root_path TEXT,
    device_id INTEGER,
    file_count INTEGER,
    treehash TEXT
);
