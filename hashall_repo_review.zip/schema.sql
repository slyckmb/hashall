-- hashall/schema.sql

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS scan_session (
    id INTEGER PRIMARY KEY,
    root_path TEXT NOT NULL,
    start_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    mode TEXT,
    treehash TEXT
);

CREATE TABLE IF NOT EXISTS files (
    id INTEGER PRIMARY KEY,
    scan_id INTEGER NOT NULL REFERENCES scan_session(id) ON DELETE CASCADE,
    path TEXT NOT NULL,
    size INTEGER,
    mtime REAL,
    sha1 TEXT,
    inode INTEGER,
    device_id INTEGER,
    is_hardlink INTEGER DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_files_scan_id ON files(scan_id);
CREATE INDEX IF NOT EXISTS idx_files_sha1 ON files(sha1);

-- Tree-level hashes (for subtree deduplication)
CREATE TABLE IF NOT EXISTS tree_hashes (
    id INTEGER PRIMARY KEY,
    scan_session_id INTEGER NOT NULL REFERENCES scan_session(id) ON DELETE CASCADE,
    root_path TEXT,
    device_id INTEGER,
    file_count INTEGER,
    treehash TEXT
);
