# src/hashall/model.py

import sqlite3
from dataclasses import dataclass
from typing import List, Any

def connect_db(db_path):
    """Open a connection to the SQLite database at db_path."""
    return sqlite3.connect(str(db_path))

def load_json_scan_into_db(conn, json_path):
    """
    Stub for loading scan JSON data into the DB.
    You can implement this based on your JSON schema.
    """
    import orjson
    with open(json_path, "rb") as f:
        data = orjson.loads(f.read())
    print(f"📝 Loaded JSON scan into DB (stub, records parsed: {len(data.get('files', []))})")

def fetch_scan_results(db_path):
    """
    Retrieve aggregated scan results for export.
    Customize SQL to match your actual tables: file_hash, scan_session, etc.
    """
    conn = connect_db(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM file_hash")
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]

@dataclass
class DiffReport:
    changed_files: List[str]
    added_files: List[str]
    removed_files: List[str]