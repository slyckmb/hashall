"""
verify_trees.py — Main high-level smart-verify orchestrator
"""

from pathlib import Path
from hashall.verify import verify_paths
from hashall.manifest import write_rsync_manifest
from hashall.repair import run_rsync_repair
from hashall.verify_session import save_verify_session

def verify_trees(
    src_root: Path,
    dst_root: Path,
    db_path: Path,
    repair: bool = False,
    dry_run: bool = True,
    rsync_source: Path = None
):
    """
    Smart verify two trees:
    - Imports scan_session JSONs if available
    - Runs or reuses scans
    - Performs DB diff
    - Optionally writes rsync manifest and runs repair
    - Logs verify session
    """

    # Step 1: Run core diff logic
    scan_id_src, scan_id_dst, diff_rows = verify_paths(
        db_path=db_path,
        src_root=src_root,
        dst_root=dst_root,
        dry_run=dry_run
    )

    # Step 2: Write rsync manifest if there are diffs
    manifest_path = dst_root / ".hashall" / "rsync_manifest.txt"
    if diff_rows and rsync_source:
        write_rsync_manifest(
            db_path=db_path,
            scan_id_src=scan_id_src,
            scan_id_dst=scan_id_dst,
            manifest_path=manifest_path
        )

        if repair:
            run_rsync_repair(
                manifest_path=manifest_path,
                src=rsync_source,
                dst=dst_root,
                dry_run=dry_run
            )

    # Step 3: Save verify session
    save_verify_session(
        session_dir=dst_root / ".hashall",
        metadata={
            "src_root": str(src_root),
            "dst_root": str(dst_root),
            "scan_id_src": scan_id_src,
            "scan_id_dst": scan_id_dst,
            "file_count_diff": len(diff_rows),
            "rsync_manifest": str(manifest_path) if manifest_path.exists() else None,
            "repaired": repair and not dry_run
        }
    )
