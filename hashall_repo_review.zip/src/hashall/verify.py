#!/usr/bin/env python3
"""
verify.py – Verifies file integrity against stored hash records.
"""

import os
import sqlite3
from rich.console import Console
from rich.table import Table

from hashall.db import connect_db, load_json_scan_into_db
from hashall.diff import diff_scan_sessions
from hashall.utils import find_db_path, find_json_path
from hashall.export import export_json

console = Console()

def verify_paths(db_path, target_paths):
    """Verify if files in target_paths match stored hashes"""
    conn = connect_db(db_path)
    cursor = conn.cursor()
    
    for path in target_paths:
        console.print(f"[bold cyan]Verifying:[/] {path}")
        cursor.execute(
            "SELECT path, hash FROM filehash WHERE path LIKE ?", 
            (f"{path}%",)
        )
        matches = cursor.fetchall()
        for record in matches:
            console.print(f" • {record[0]} [hash: {record[1]}]")
    
    conn.close()

def verify_from_json(json_path, db_path=None):
    """Load scan JSON and verify it by comparing to existing DB"""
    if not db_path:
        db_path = find_db_path()
    json_path = find_json_path(json_path)

    conn = connect_db(db_path)
    src_session = load_json_scan_into_db(conn, json_path)
    dst_session = "latest"  # In practice, this could be parameterized

    diff_report = diff_scan_sessions(conn, src_session, dst_session)

    table = Table(title="Diff Summary")
    table.add_column("File", style="dim", overflow="fold")
    table.add_column("Status", style="bold")

    for entry in diff_report.entries:
        table.add_row(entry.path, entry.status)

    console.print(table)

    conn.close()

def verify_and_export(json_path=None, db_path=None):
    """Verify scan and export clean results"""
    verify_from_json(json_path, db_path)
    export_json(db_path)