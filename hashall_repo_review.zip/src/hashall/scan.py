#!/usr/bin/env python3
"""
scan.py – Scans files and records results in a SQLite DB.
"""

import os
import uuid
import time
import socket
import getpass
import threading
from pathlib import Path
from queue import Queue
from datetime import datetime
from collections import defaultdict

import sqlite3

# Global hardlink tracker by (dev, inode)
seen_inodes = defaultdict(list)

def scan_path(db_path, root_path, mode="scan", parallel=False):
    """
    Scan a directory and record file metadata into the SQLite DB.
    """
    root_path = Path(root_path).resolve()
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row

    os.makedirs(db_path.parent, exist_ok=True)

    scan_id = str(uuid.uuid4())
    start_time = datetime.utcnow().isoformat()
    hostname = socket.gethostname()
    user = getpass.getuser()

    # Create table if needed
    conn.execute("""
        CREATE TABLE IF NOT EXISTS scan_session (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            scan_id TEXT,
            start_time TEXT,
            root_path TEXT,
            hostname TEXT,
            user TEXT
        )
    """)
    conn.execute("""
        INSERT INTO scan_session (scan_id, start_time, root_path, hostname, user)
        VALUES (?, ?, ?, ?, ?)
    """, (scan_id, start_time, str(root_path), hostname, user))

    conn.commit()
    print(f"✅ Scan session started: {scan_id} — {root_path}")

    # Walk directory and record basic info
    for dirpath, _, filenames in os.walk(root_path):
        for filename in filenames:
            full_path = Path(dirpath) / filename
            stat = full_path.stat()
            conn.execute("INSERT INTO files (path, size, mtime) VALUES (?, ?, ?)", (str(full_path), stat.st_size, stat.st_mtime))

    conn.commit()
    print("📦 Scan complete.")
