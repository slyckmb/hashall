# src/hashall/export.py
import json
from pathlib import Path
from hashall.model import fetch_scan_results

def export_json(db_path, out_path=None):
    """Export scan results to JSON file"""
    data = fetch_scan_results(db_path)
    out_path = Path(out_path or Path.home() / ".hashall" / "hashall.json")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    print(f"✅ Exported to {out_path}")