#!/usr/bin/env python3
"""
cli.py — Hashall command-line interface
"""

import click
from pathlib import Path

from hashall.scan import scan_path
from hashall.export import export_json
from hashall.verify_trees import verify_trees
from hashall import __version__

DEFAULT_DB_PATH = Path.home() / ".hashall" / "hashall.sqlite3"

@click.group()
@click.version_option(__version__)
def cli():
    """Hashall — file hashing, verification, and migration tools"""
    pass

@cli.command("scan")
@click.argument("path", type=click.Path(exists=True, file_okay=False))
@click.option("--db", type=click.Path(), default=DEFAULT_DB_PATH, help="SQLite DB path.")
def scan_cmd(path, db):
    """Scan a directory and store file metadata in SQLite."""
    scan_path(db_path=Path(db), root_path=Path(path))

@cli.command("export")
@click.argument("path", type=click.Path(exists=True, file_okay=False))
@click.option("--db", type=click.Path(), default=DEFAULT_DB_PATH, help="SQLite DB path.")
def export_cmd(path, db):
    """Export metadata from SQLite to JSON."""
    export_json(db_path=Path(db), root_path=Path(path))

@cli.command("verify-trees")
@click.argument("seed", type=click.Path(exists=True, file_okay=False))
@click.argument("backup", type=click.Path(exists=True, file_okay=False))
@click.option("--force", is_flag=True, help="Force verify all files.")
def verify_trees_cmd(seed, backup, force):
    """Verify that backup tree matches the seed tree."""
    verify_trees(seed, backup, force=force)
